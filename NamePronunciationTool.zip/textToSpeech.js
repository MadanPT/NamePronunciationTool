function UserAction() {
    debugger;
    
    var nameToPronunce=document.getElementById('inputName').value;
    //Test(nameToPronunce);
    GetAcessToken().then((accessToken)=>{
   
    let data="<speak version='1.0' xml:lang='en-US'><voice xml:lang='en-US' xml:gender='Male' name='en-US-ChristopherNeural'>{0}</voice></speak>";
    data= data.replace("{0}",nameToPronunce);

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
         if (this.readyState == 4 && this.status == 200) {
                 saveBlob(this.response,"test1243");
         }
    };
    xhttp.open("POST", "https://eastus.tts.speech.microsoft.com/cognitiveservices/v1", true);
    xhttp.setRequestHeader("Content-type", "application/ssml+xml");
    xhttp.setRequestHeader("Authorization", "Bearer "+accessToken);
    xhttp.setRequestHeader("Host", "eastus.api.cognitive.microsoft.com");
    xhttp.setRequestHeader("X-Microsoft-OutputFormat", "ogg-16khz-16bit-mono-opus");
    xhttp.setRequestHeader("User-Agent", "TextToSpeech");
    xhttp.responseType='blob';
    
    xhttp.send(data);
});
}

function UserActionRecord() {
    debugger;
    
    var nameToPronunce=document.getElementById('inputName').value;
    //Test(nameToPronunce);
    GetAcessToken().then((accessToken)=>{
   
    let data="<speak version='1.0' xml:lang='en-US'><voice xml:lang='en-US' xml:gender='Male' name='en-US-ChristopherNeural'>{0}</voice></speak>";
    data= data.replace("{0}",nameToPronunce);

    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
         if (this.readyState == 4 && this.status == 200) {
                 saveBlob(this.response,"test1243_record");
         }
    };
    xhttp.open("POST", "https://eastus.tts.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language=en-US&format=detailed", true);
    xhttp.setRequestHeader("Content-type", "audio/wav; codecs=audio/pcm; samplerate=16000");
    xhttp.setRequestHeader("Authorization", "Bearer "+accessToken);
    xhttp.setRequestHeader("Host", "eastus.api.cognitive.microsoft.com");
    xhttp.setRequestHeader("Accept", "application/json;text/xml");
    xhttp.setRequestHeader("Expect", "100-continue");
    xhttp.setRequestHeader("Transfer-Encoding", "chunked");
    //xhttp.responseType='blob';
    
    xhttp.send(data);
});
}


function saveBlob(blob, fileName) {
    var path=window.URL.createObjectURL(blob);
    // var a = document.createElement('a');
    // a.href = window.URL.createObjectURL(blob);
    // a.download = "./"+fileName;
    // a.dispatchEvent(new MouseEvent('click'));
    var element=document.getElementById("playaudio");
    element.src=path;
    element.play();
}
function GetAcessToken()
{
    return new Promise(function(resolve,reject){
    var xhttp = new XMLHttpRequest();

    xhttp.onreadystatechange = function() {
         if (this.readyState == 4 && this.status == 200) {
            resolve(this.responseText);
         }
    };
    xhttp.open("POST", "https://eastus.api.cognitive.microsoft.com/sts/v1.0/issueToken", true);
    xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhttp.setRequestHeader("Host", "eastus.api.cognitive.microsoft.com");
    xhttp.setRequestHeader("Ocp-Apim-Subscription-Key", "d5ff523894d841b185f98d53441cc3f8");
    xhttp.send();
});
}

function Test(text)
{
   // var sdk = require(['microsoft.cognitiveservices.speech.sdk']);
    //var readline = require('readline');

    var key = "d5ff523894d841b185f98d53441cc3f8";
    var region = "eastus";
    var audioFile = "textToSpeech.wav";

    const speechConfig = sdk.SpeechConfig.fromSubscription(key, region);
    const audioConfig = sdk.AudioConfig.fromAudioFileOutput(audioFile);

    // The language of the voice that speaks.
    speechConfig.speechSynthesisVoiceName = "en-US-JennyNeural"; 

    // Create the speech synthesizer.
    var synthesizer = new sdk.SpeechSynthesizer(speechConfig, audioConfig);

    // var rl = readline.createInterface({
    //   input: process.stdin,
    //   output: process.stdout
    // });

    //rl.question("Enter some text that you want to speak >\n> ", function (text) {
      //rl.close();
      // Start the synthesizer and wait for a result.
      synthesizer.speakTextAsync(text,
          function (result) {
        if (result.reason === ResultReason.SynthesizingAudioCompleted) {
          console.log("synthesis finished.");
        } else {
          console.error("Speech synthesis canceled, " + result.errorDetails +
              "\nDid you set the speech resource key and region values?");
        }
        synthesizer.close();
        synthesizer = null;
      },
          function (err) {
        console.trace("err - " + err);
        synthesizer.close();
        synthesizer = null;
      });
      console.log("Now synthesizing to: " + audioFile);
   // });
}